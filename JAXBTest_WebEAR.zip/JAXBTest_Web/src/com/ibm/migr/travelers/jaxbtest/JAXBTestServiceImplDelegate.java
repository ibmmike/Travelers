package com.ibm.migr.travelers.jaxbtest;

import javax.jws.WebService;


@WebService (targetNamespace="http://jaxbtest.travelers.migr.ibm.com/", serviceName="JAXBTestServiceImplService", portName="JAXBTestServiceImplPort", wsdlLocation="WEB-INF/wsdl/JAXBTestServiceImplService.wsdl")
public class JAXBTestServiceImplDelegate{

    com.ibm.migr.travelers.jaxbtest.JAXBTestServiceImpl _jAXBTestServiceImpl = null;

    public String parseXML (String inXML) {
        return _jAXBTestServiceImpl.parseXML(inXML);
    }

    public JAXBTestServiceImplDelegate() {
        _jAXBTestServiceImpl = new com.ibm.migr.travelers.jaxbtest.JAXBTestServiceImpl(); }

}