package com.ibm.migr.travelers.jaxbtest;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;


@WebService(name = "JAXBTestService", targetNamespace = "http://com/ibm/migr/travelers/jaxbtest")
@SOAPBinding(style = SOAPBinding.Style.DOCUMENT)
public interface JAXBTestService {

	@WebMethod
	public String parseXML(@WebParam(name="inXML") String inXML);
	
}
