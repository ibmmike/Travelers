/**
 * 
 */
package com.ibm.migr.travelers.jaxbtest;

import java.io.Reader;
import java.io.StringReader;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import com.ibm.migr.travelers.jaxbtest.types.DBLP;

/**
 * @author mikecai
 *
 */
public class JAXBTestServiceImpl implements JAXBTestService {

	private JAXBContext jaxbContext;
	
	/**
	 * 
	 */
	public JAXBTestServiceImpl() {
		super();
		try {
			jaxbContext = JAXBContext.newInstance(DBLP.class);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}

/*	class MySchemaOutputResolver extends SchemaOutputResolver {

	    public Result createOutput(String namespaceURI, String suggestedFileName) throws IOException {
	        File file = new File("/Users/mikecai/Desktop/dblp.xsd");
	        StreamResult result = new StreamResult(file);
	        result.setSystemId(file.toURI().toURL().toString());
	        return result;
	    }

	}*/
	
	/* (non-Javadoc)
	 * @see com.ibm.migr.travelers.jaxbtest.JAXBTestService#parseXML(com.ibm.migr.travelers.jaxbtest.types.POLICY)
	 */
	@Override
	public String parseXML(String inXML) {

/*//		JAXBContext jaxbContext = JAXBContext.newInstance(Customer.class);
		SchemaOutputResolver sor = new MySchemaOutputResolver();
		try {
			jaxbContext.generateSchema(sor);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}*/
		
		try {
			
			Unmarshaller u = jaxbContext.createUnmarshaller();
			Reader reader = new StringReader(inXML);
			JAXBElement<DBLP> jaxB = (JAXBElement<DBLP>) u.unmarshal(reader);
			DBLP dblp = jaxB.getValue();
			
		} catch (JAXBException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return "Parsing Successful";
	}

}
