@javax.xml.bind.annotation.XmlSchema(namespace = "http://jaxbtest.travelers.migr.ibm.com/")
package com.ibm.migr.travelers.jaxbtest;
