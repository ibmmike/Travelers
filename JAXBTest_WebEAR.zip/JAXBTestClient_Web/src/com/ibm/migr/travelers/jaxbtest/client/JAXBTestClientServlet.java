package com.ibm.migr.travelers.jaxbtest.client;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.Properties;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ibm.migr.travelers.jaxbtest.JAXBTestServiceImplPortProxy;

/**
 * Servlet implementation class JAXBTestClientServlet
 */
@WebServlet("/JAXBTestClientServlet")
public class JAXBTestClientServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private final String BATCH_COUNT_KEY = "BATCH_COUNT";
	private final String BATCH_SIZE_KEY = "BATCH_SIZE";
	private final String BATCH_WAIT_TIME = "BATCH_WAIT_TIME";
	private final String THREAD_WAIT_TIME = "THREAD_WAIT_TIME";
	
	private final String inXML;
    
    /**
     * @see HttpServlet#HttpServlet()
     */
    public JAXBTestClientServlet() {
        super();
        
        // Load XML into String
        InputStream inputStream = getClass().getResourceAsStream("/dblp_test_.xml");
        	BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream ));
        String line;
        StringBuilder sb = new StringBuilder();
        
        try {
			while((line=reader.readLine())!= null){
			    sb.append(line.trim());
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
        inXML = sb.toString();
        // System.out.println(inXML);
        
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		File file = new File("//opt/IBM/wlp-ee7-full-17.0.0.2/usr/servers/TravelersServer3/config/config.properties");
		FileInputStream inputStream = new FileInputStream(file);
		
//        InputStream inputStream = getClass().getResourceAsStream("");
        BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
        Properties props = new Properties();
        props.load(reader);
        
        int batchCount = Integer.parseInt(props.getProperty(BATCH_COUNT_KEY, "1"));
        int batchSize = Integer.parseInt(props.getProperty(BATCH_SIZE_KEY, "1"));
        int batchWaitTime = Integer.parseInt(props.getProperty(BATCH_WAIT_TIME, "1000"));
        int runWaitTime = Integer.parseInt(props.getProperty(THREAD_WAIT_TIME, "0"));

		JAXBTestServiceImplPortProxy port = new JAXBTestServiceImplPortProxy();
		
		//System.out.println("JAXBTestClientServlet.doGet(): inXML = ");
		//System.out.println(inXML);
		//System.out.println();
		
		
		for (int j=0; j < batchCount; j++) {
		
			Collection<Thread> threadPool = new ArrayList<Thread>();
			
			final long currBatchCount = j + 1;
			
			for (int i=0; i < batchSize; i++) {
				
				final long count = i + 1;
				
				Thread t = new Thread(new Runnable() {
					String resp = "BAD RESPONSE";
					
				    @Override
				    public void run() {
				    		System.out.println("Running - " + currBatchCount + "." + count);
				    		resp = port.parseXML(inXML);
						System.out.println(resp + " - " + currBatchCount + "." + count);
				    }
				});
				
				threadPool.add(t);
			}
			
			Iterator<Thread> iter = threadPool.iterator();
			
			while (iter.hasNext()) { 
				iter.next().start();
				try {
					Thread.sleep(runWaitTime);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			try {
				Thread.sleep(batchWaitTime);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	
		response.getWriter().append("<html><body><h3>Test has began, check logs for details.").flush();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
