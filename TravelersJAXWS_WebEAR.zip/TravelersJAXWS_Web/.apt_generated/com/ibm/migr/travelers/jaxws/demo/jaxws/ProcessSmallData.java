
package com.ibm.migr.travelers.jaxws.demo.jaxws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "processSmallData", namespace = "http://demo.jaxws.travelers.migr.ibm.com/")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "processSmallData", namespace = "http://demo.jaxws.travelers.migr.ibm.com/")
public class ProcessSmallData {


}
