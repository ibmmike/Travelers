package com.ibm.migr.travelers.jaxws.demo;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;

@WebService(name = "JAXWSDemoService", targetNamespace = "http://com/ibm/migr/travelers/jaxws/demo")
@SOAPBinding(style = SOAPBinding.Style.DOCUMENT)
public interface JAXWSDemoService {

	@WebMethod
	public String processSmallData();
	
	@WebMethod
	public String processLargeData();
	
}
