package com.ibm.migr.travelers.jaxws.demo;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class JAXWSDemoServiceImpl implements JAXWSDemoService {

	private DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
	
	@Override
	public String processSmallData(String msg) {
		
		Date date = new Date();
		System.out.println("JAXWSDemoServiceImpl.processSmallData(): Begin processing small data - " + dateFormat.format(date));
		
		try {
			Thread.sleep(30000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		date = new Date();
		System.out.println("JAXWSDemoServiceImpl.processSmallData(): Completed processing small data - " + dateFormat.format(date));
		
		return "Small Data Processed in 30s";
	}

	@Override
	public String processLargeData(String msg) {
		
		Date date = new Date();
		System.out.println("JAXWSDemoServiceImpl.processLargeData(): Begin processing large data - " + dateFormat.format(date));
		
		try {
			Thread.sleep(120000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		date = new Date();
		System.out.println("JAXWSDemoServiceImpl.processLargeData(): Begin processing large data - " + dateFormat.format(date));
		
		return "Large Data Processed in 120s";
	}

}
