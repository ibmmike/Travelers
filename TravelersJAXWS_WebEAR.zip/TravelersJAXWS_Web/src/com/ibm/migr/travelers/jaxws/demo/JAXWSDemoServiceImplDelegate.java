package com.ibm.migr.travelers.jaxws.demo;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.jws.WebService;


@WebService (targetNamespace="http://demo.jaxws.travelers.migr.ibm.com/", serviceName="JAXWSDemoServiceImplService", portName="JAXWSDemoServiceImplPort", wsdlLocation="WEB-INF/wsdl/JAXWSDemoServiceImplService.wsdl")
public class JAXWSDemoServiceImplDelegate{

    com.ibm.migr.travelers.jaxws.demo.JAXWSDemoServiceImpl _jAXWSDemoServiceImpl = null;

    public String processSmallData (String msg) {
        return _jAXWSDemoServiceImpl.processSmallData(msg);
    }

    public String processLargeData (String msg) {
        return _jAXWSDemoServiceImpl.processLargeData(msg);
    }

    public JAXWSDemoServiceImplDelegate() {
        _jAXWSDemoServiceImpl = new com.ibm.migr.travelers.jaxws.demo.JAXWSDemoServiceImpl(); }

}