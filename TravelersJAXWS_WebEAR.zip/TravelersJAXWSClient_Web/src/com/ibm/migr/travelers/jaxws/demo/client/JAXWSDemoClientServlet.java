package com.ibm.migr.travelers.jaxws.demo.client;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.namespace.QName;
import javax.xml.ws.Service;
import javax.xml.ws.WebServiceRef;

import org.apache.cxf.endpoint.Client;
import org.apache.cxf.frontend.ClientProxy;
import org.apache.cxf.transport.http.HTTPConduit;
import org.apache.cxf.transports.http.configuration.HTTPClientPolicy;

import com.ibm.migr.travelers.jaxws.demo.JAXWSDemoServiceImplDelegate;
import com.ibm.migr.travelers.jaxws.demo.JAXWSDemoServiceImplService;
import com.sun.xml.internal.ws.client.BindingProviderProperties;

/**
 * Servlet implementation class JAXWSDemoClientServlet
 */
@WebServlet("/JAXWSDemoClientServlet")
public class JAXWSDemoClientServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	@WebServiceRef(name="service/JAXWSDemoServiceImplService")
	JAXWSDemoServiceImplService service;
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public JAXWSDemoClientServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//URL wsdlLocation = new URL("http://localhost:9080/TravelersJAXWS_Web/JAXWSDemoServiceImplService?wsdl");
		
		response.getWriter().append("<html><body><p>" + "Clients triggered, check log for results..." + "</body></html>");
		response.flushBuffer();
		
	
		// Create port using service reference
		JAXWSDemoServiceImplDelegate port = service.getJAXWSDemoServiceImplPort();
		
		
		// Create port using Java proxy
		URL wsdlLocation = new URL("http://localhost:9080/TravelersJAXWS_Web/JAXWSDemoServiceImplService?wsdl");
		QName serviceName = new QName("http://demo.jaxws.travelers.migr.ibm.com/", "JAXWSDemoServiceImplService");
		Service s = Service.create(wsdlLocation, serviceName);
		JAXWSDemoServiceImplDelegate port2 = s.getPort(JAXWSDemoServiceImplDelegate.class);
/*
		Client client = ClientProxy.getClient(port2);
		HTTPConduit http = (HTTPConduit)client.getConduit();
		HTTPClientPolicy httpClientPolicy = new HTTPClientPolicy();
		httpClientPolicy.setConnectionTimeout(300000);
		httpClientPolicy.setReceiveTimeout(300000);
		http.setClient(httpClientPolicy);
*/
///*
		Map<String, Object> reqCtx = ((javax.xml.ws.BindingProvider)port).getRequestContext();
		reqCtx.put(BindingProviderProperties.REQUEST_TIMEOUT, new Long(300000));
		reqCtx.put(BindingProviderProperties.CONNECT_TIMEOUT, new Long(300000));
		reqCtx.put("http.conduit.client.ConnectionTimeout", new Long(300000));
		reqCtx.put("http.conduit.client.ReceiveTimeout", new Long(300000));
		reqCtx.put("cxf.client.connectionTimeout", new Long(300000));
		reqCtx.put("cxf.client.receiveTimeout", new Long(300000));
//*/
		
		
		
		// invoke service using both port client.
		new Thread(new Runnable() {
			String resp = "BAD RESPONSE";
			
		    @Override
		    public void run() {
/*
		    		resp = port.processSmallData("");
				System.out.println(resp);
				
				resp = port.processLargeData("");
				System.out.println(resp);
*/				
				resp = port2.processSmallData("");
				System.out.println(resp);
				
				// This will timeout!
				resp = port2.processLargeData("");
				System.out.println(resp);
		    }
		    
		}).start();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
