
package com.ibm.migr.travelers.jaxws.demo;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.ibm.migr.travelers.jaxws.demo package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _ProcessLargeData_QNAME = new QName("http://demo.jaxws.travelers.migr.ibm.com/", "processLargeData");
    private final static QName _ProcessLargeDataResponse_QNAME = new QName("http://demo.jaxws.travelers.migr.ibm.com/", "processLargeDataResponse");
    private final static QName _ProcessSmallDataResponse_QNAME = new QName("http://demo.jaxws.travelers.migr.ibm.com/", "processSmallDataResponse");
    private final static QName _ProcessSmallData_QNAME = new QName("http://demo.jaxws.travelers.migr.ibm.com/", "processSmallData");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.ibm.migr.travelers.jaxws.demo
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link ProcessSmallData }
     * 
     */
    public ProcessSmallData createProcessSmallData() {
        return new ProcessSmallData();
    }

    /**
     * Create an instance of {@link ProcessSmallDataResponse }
     * 
     */
    public ProcessSmallDataResponse createProcessSmallDataResponse() {
        return new ProcessSmallDataResponse();
    }

    /**
     * Create an instance of {@link ProcessLargeData }
     * 
     */
    public ProcessLargeData createProcessLargeData() {
        return new ProcessLargeData();
    }

    /**
     * Create an instance of {@link ProcessLargeDataResponse }
     * 
     */
    public ProcessLargeDataResponse createProcessLargeDataResponse() {
        return new ProcessLargeDataResponse();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ProcessLargeData }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://demo.jaxws.travelers.migr.ibm.com/", name = "processLargeData")
    public JAXBElement<ProcessLargeData> createProcessLargeData(ProcessLargeData value) {
        return new JAXBElement<ProcessLargeData>(_ProcessLargeData_QNAME, ProcessLargeData.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ProcessLargeDataResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://demo.jaxws.travelers.migr.ibm.com/", name = "processLargeDataResponse")
    public JAXBElement<ProcessLargeDataResponse> createProcessLargeDataResponse(ProcessLargeDataResponse value) {
        return new JAXBElement<ProcessLargeDataResponse>(_ProcessLargeDataResponse_QNAME, ProcessLargeDataResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ProcessSmallDataResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://demo.jaxws.travelers.migr.ibm.com/", name = "processSmallDataResponse")
    public JAXBElement<ProcessSmallDataResponse> createProcessSmallDataResponse(ProcessSmallDataResponse value) {
        return new JAXBElement<ProcessSmallDataResponse>(_ProcessSmallDataResponse_QNAME, ProcessSmallDataResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ProcessSmallData }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://demo.jaxws.travelers.migr.ibm.com/", name = "processSmallData")
    public JAXBElement<ProcessSmallData> createProcessSmallData(ProcessSmallData value) {
        return new JAXBElement<ProcessSmallData>(_ProcessSmallData_QNAME, ProcessSmallData.class, null, value);
    }

}
