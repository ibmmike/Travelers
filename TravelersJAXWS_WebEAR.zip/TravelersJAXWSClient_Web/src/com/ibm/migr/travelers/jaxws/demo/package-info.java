@javax.xml.bind.annotation.XmlSchema(namespace = "http://demo.jaxws.travelers.migr.ibm.com/")
package com.ibm.migr.travelers.jaxws.demo;
